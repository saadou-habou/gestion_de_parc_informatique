# Instructions d'intégration

Aucune règle métier existante n'a été modifiée ou supprimée. Un nouveau
modèle a été ajouté (comme demandé) pour permettre un véritable historique
des affectations appareil ↔ utilisateur.

## Nouveau : section Maintenances

Deux nouvelles vues complètent le cycle de vie d'une intervention (jusqu'ici,
rien ne remettait un appareil "Disponible" après réparation) :

- **`liste_maintenances`** (`/maintenances/`) : vue globale, toutes
  interventions confondues, avec recherche instantanée, filtres par statut,
  cartes stats et pagination.
- **`terminer_maintenance`** (`/maintenances/<id>/terminer/`, POST) : marque
  une intervention comme "Réparé" et repasse l'appareil à "Disponible" — mais
  **seulement** s'il n'a plus d'autre maintenance "Non réparé" ouverte (un
  appareil peut avoir plusieurs interventions non résolues en parallèle).

Cette action est disponible à deux endroits : dans la liste globale des
maintenances, et dans l'historique de maintenance par appareil (bouton
"Terminer" sur chaque ligne non réparée). Le lien "Maintenances" de la
sidebar, jusqu'ici désactivé, est maintenant actif.

## Nouveau modèle : `HistoriqueAffectation`

```python
class HistoriqueAffectation(models.Model):
    appareil = models.ForeignKey(Appareil, on_delete=models.CASCADE, related_name="affectations")
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.SET_NULL, null=True, related_name="affectations")
    date_debut = models.DateField(default=timezone.now)
    date_fin = models.DateField(blank=True, null=True)
```

- `date_fin = None` ⇒ affectation en cours (propriété `en_cours`).
- `on_delete=models.SET_NULL` sur `utilisateur` : si un utilisateur est
  supprimé, l'historique de ses affectations passées est conservé (avec
  "Utilisateur retiré" affiché côté template) plutôt que d'être perdu.
- Le champ existant `Appareil.utilisateur` **n'a pas changé** : il continue
  de représenter l'affectation actuelle ; `HistoriqueAffectation` est un
  ajout, pas un remplacement.

## Comment l'historique se remplit

Plutôt qu'un signal Django "magique" (moins lisible, plus difficile à
déboguer), l'historisation est **explicite dans les vues**, ce qui reste
cohérent avec le style du reste du code :

1. **`ajouter_appareil`** : si un utilisateur est choisi dès la création,
   une première ligne d'historique "en cours" est ouverte.
2. **`affecter_appareil`** *(nouvelle vue, nouvelle page dédiée)* : clôture
   l'affectation en cours (si elle existe) à la date du jour, puis ouvre une
   nouvelle ligne pour le nouvel utilisateur (ou n'en ouvre aucune si
   l'appareil est désaffecté).
3. Toutes les autres vues (`modifier_appareil`, qui ne touche qu'à `etat`)
   sont **inchangées** et ne peuvent pas modifier l'utilisateur, donc ne
   peuvent pas créer d'incohérence dans l'historique.

## Rétro-remplissage des données existantes

Une commande de management est fournie pour ne pas perdre les affectations
déjà en place au moment de l'activation de cette fonctionnalité :

```bash
python manage.py backfill_affectations
```

Elle crée une ligne "en cours" pour chaque appareil déjà affecté qui n'a pas
encore d'entrée d'historique correspondante. Sans danger à relancer
plusieurs fois (idempotente).

## Étapes de migration Django

```bash
python manage.py makemigrations parc_informatique
python manage.py migrate
python manage.py backfill_affectations
```

## Nouvelles pages

| URL | Vue | Rôle |
|---|---|---|
| `/appareils/<id>/affecter/` | `affecter_appareil` | Formulaire pour changer/retirer l'utilisateur d'un appareil |
| `/appareils/<id>/affectations/` | `historique_affectations` | Timeline des affectations passées et en cours d'un appareil |
| `/utilisateurs/<id>/` | `profil_utilisateur` | Affiche désormais aussi l'historique complet des affectations de l'utilisateur, en plus des appareils actuels |

Depuis la fiche d'un appareil, deux nouveaux boutons apparaissent :
**"Changer d'affectation"** et **"Historique des affectations"**.

## Fichiers à copier dans votre projet

```
parc_informatique/models.py      (remplace l'existant — ajoute HistoriqueAffectation)
parc_informatique/forms.py       (remplace l'existant — ajoute AffectationForm)
parc_informatique/views.py       (remplace l'existant)
parc_informatique/urls.py        (remplace l'existant)
parc_informatique/management/__init__.py
parc_informatique/management/commands/__init__.py
parc_informatique/management/commands/backfill_affectations.py

templates/parc_informatique/base.html
templates/parc_informatique/dashboard.html
templates/parc_informatique/index.html
templates/parc_informatique/afficher_appareil.html
templates/parc_informatique/appareil-form.html
templates/parc_informatique/appareil_edit_form.html
templates/parc_informatique/confirmer_suppression.html
templates/parc_informatique/envoyer_en_maintenance.html
templates/parc_informatique/historique_maintenance.html
templates/parc_informatique/affecter_appareil.html          (nouveau)
templates/parc_informatique/historique_affectations.html    (nouveau)
templates/parc_informatique/utilisateurs_liste.html
templates/parc_informatique/utilisateur_profil.html         (mis à jour : historique complet)
templates/parc_informatique/maintenances_liste.html         (nouveau)
templates/parc_informatique/include/sidebar.html
templates/parc_informatique/include/navbar.html
templates/parc_informatique/include/messages.html
templates/parc_informatique/include/footer.html
templates/parc_informatique/include/pagination.html

static/parc_informatique/css/main.css
static/parc_informatique/js/main.js
```

`404.html` / `500.html` (dans `templates_root/`) vont dans le dossier
`templates/` **à la racine du projet** (celui déclaré dans
`TEMPLATES[0]["DIRS"]` de `settings.py`). Actifs uniquement quand
`DEBUG = False`.

## Toutes les routes

| URL | Vue | Nom |
|---|---|---|
| `/` | `index` | `parc_informatique:index` |
| `/dashboard/` | `dashboard` | `parc_informatique:dashboard` |
| `/appareils/<id>/` | `afficher_appareil` | idem |
| `/ajouter-appareil/` | `ajouter_appareil` | idem |
| `/appareils/<id>/modifier/` | `modifier_appareil` | idem |
| `/appareils/<id>/supprimer/` | `supprimer_appareil` | idem |
| `/appareils/<id>/maintenance/` | `historique_maintenance` | idem |
| `/appareils/<id>/evoyer_en_maintenance/` | `envoyer_en_maintenance` | idem |
| `/appareils/<id>/affecter/` | `affecter_appareil` | **nouveau** |
| `/appareils/<id>/affectations/` | `historique_affectations` | **nouveau** |
| `/utilisateurs/` | `liste_utilisateurs` | **nouveau** |
| `/utilisateurs/<id>/` | `profil_utilisateur` | **nouveau** |
| `/maintenances/` | `liste_maintenances` | **nouveau** |
| `/maintenances/<id>/terminer/` | `terminer_maintenance` | **nouveau** |

## Anciens fichiers à supprimer

- `include/begin_page.html` et `include/end_page.html` (remplacés par
  `base.html` + `{% extends %}`).

## Autres points corrigés au passage

- `index.html` original affichait `{{ utilisateur.nom }}` sans que cette
  variable existe dans le contexte → supprimé.
- `historique_maintenance.html` original lisait `appareil.maintenances.all`,
  alors que la vue passe `historiquemaintenances` → corrigé.
- Pagination serveur (10 éléments/page) sur `index()` et `liste_utilisateurs()`,
  avec un composant réutilisable `include/pagination.html`.
